
const DOUYU_URL_ROOM = "http://open.douyucdn.cn/api/RoomApi/room/";
const DOUYU_URL_LIVE =  "http://open.douyucdn.cn/api/RoomApi/live/";

module.exports = {
    DOUYU_URL_ROOM: DOUYU_URL_ROOM,
    DOUYU_URL_LIVE: DOUYU_URL_LIVE
}

