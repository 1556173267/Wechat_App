# thinkWx
## 新增函数
```sh
	THINK.config                //读取、设置配置文件
```
```sh
	THINK.cache/cacheSync       //读取、设置本地缓存
```
```sh
	THINK.params                //读取post、get、data-参数，post优先
```
```sh
	THINK.isEmpty               //检查是否为空
```
```sh
	THINK.html2json/json2html   //html<=>json
```
```sh
	THINK.mixin                 //非构造函数继承
```
```sh
	THINK.promise               //返回Promise对象
```
## Promise封装函数
```sh
	THINK.request              
```
```sh
	THINK.getStorage            //支持同步、异步
```
```sh
	THINK.setStorage            //支持同步、异步  
```
## 模板相关
```sh
	支持html格式输出
```
