/*
 * 作者 : ihanyu
 * QQ  : 1016053132
 * 目前只支持二级嵌套，不支持多级
 */
var config={
    "domain" : "http://127.0.0.1:3000/",   //域名
    "aaa":{
        "aaa":"aaaaaaaaaa"
    }
};
module.exports = config;
